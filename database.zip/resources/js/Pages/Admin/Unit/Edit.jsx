import React, { useState } from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link, router } from '@inertiajs/react';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';
import PrimaryButton from '@/Components/PrimaryButton';
import InputError from '@/Components/InputError';
import CustomSelect from '@/Components/CustomSelect'; 
import FieldTooltipError from '@/Components/FieldTooltipError';
import { Building2, Save, ArrowLeft, Settings2, UserCircle, Phone, Mail, PencilLine } from 'lucide-react';
import { toast } from 'sonner';

export default function Edit({ auth, unit, users, units, approvalPaths }) {
    const [formErrors, setFormErrors] = useState({});

    // 1. SETUP FORM: Ganti 'put' menjadi 'patch'
    const { data, setData, patch, processing, errors, reset } = useForm({
        kode_unit: unit.kode_unit || '',
        nama_unit: unit.nama_unit || '',
        tipe_unit: unit.tipe_unit || 'Unit',
        approval_path_id: unit.approval_path_id || '',
        id_kepala: unit.id_kepala || '',
        parent_id: unit.parent_id || '',
        no_telepon: unit.no_telepon || '',
        email: unit.email || '',
    });

    const handleFieldChange = (field, value) => {
        setData(field, value);
        if (formErrors[field]) {
            setFormErrors(prev => ({ ...prev, [field]: null }));
        }
    };

    const submit = (e) => {
        e.preventDefault();

        const errs = {};
        if (!data.kode_unit) errs.kode_unit = 'Harap isi bidang ini.';
        if (!data.nama_unit) errs.nama_unit = 'Harap isi bidang ini.';
        if (!data.tipe_unit) errs.tipe_unit = 'Harap isi bidang ini.';
        if (!data.approval_path_id) errs.approval_path_id = 'Harap isi bidang ini.';

        if (Object.keys(errs).length > 0) {
            setFormErrors(errs);
            toast.error("Peringatan", { description: "Semua form bertanda * wajib diisi." });
            return;
        }

        setFormErrors({});
        toast.warning("Konfirmasi Simpan", {
            description: "Apakah Anda yakin ingin menyimpan perubahan unit kerja ini?",
            action: {
                label: "Ya, Simpan",
                onClick: () => {
                    const toastId = toast.loading("Sedang memperbarui data...");
                    patch(route('unit.update', unit.uuid || unit.id_unit), {
                        onSuccess: () => toast.success("Berhasil", { id: toastId, description: `Data Unit Kerja ${data.nama_unit} berhasil diperbarui.` }),
                        onError: () => toast.error("Gagal Memperbarui", { id: toastId, description: "Terdapat kesalahan saat memperbarui data." })
                    });
                }
            },
            cancel: { label: "Batal" }
        });
    };

    const handleBack = () => {
        toast.warning("Konfirmasi Batal", {
            description: "Yakin ingin membatalkan? Perubahan yang belum disimpan akan hilang.",
            action: {
                label: "Ya, Batal",
                onClick: () => router.get(route('unit.index'))
            },
            cancel: { label: "Lanjut" }
        });
    };

    // 2. OPSI DROPDOWN
    const tipeOptions = [
        { value: 'Rektorat', label: 'Rektorat' },
        { value: 'Fakultas', label: 'Fakultas' },
        { value: 'Prodi', label: 'Program Studi (Prodi)' },
        { value: 'Biro', label: 'Biro' },
        { value: 'Lembaga', label: 'Lembaga' },
        { value: 'UPT', label: 'Unit Pelaksana Teknis (UPT)' },
        { value: 'Satuan', label: 'Satuan' },
        { value: 'UKM', label: 'Unit Kegiatan Mahasiswa (UKM)' },
        { value: 'Unit', label: 'Unit Kerja' },
        { value: 'Admin', label: 'Administrator' },
        { value: 'Lainnya', label: 'Lainnya' },
    ];

    const userOptions = [
        { value: '', label: 'Tanpa Kepala Unit (Kosong)' },
        ...users.map(u => ({ value: u.id_user, label: u.nama_lengkap }))
    ];
    
    const parentOptions = [
        { value: '', label: 'Tanpa Unit Induk (Top Level / Kosong)' },
        ...units
            .filter(u => u.id_unit !== unit.id_unit)
            .map(u => ({ value: u.id_unit, label: `${u.kode_unit} - ${u.nama_unit}` }))
    ];

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Edit Unit Kerja</h2>}
        >
            <Head title={`Edit ${data.nama_unit}`} />

            <div className="py-6 pb-24">
                <div className="max-w-4xl mx-auto sm:px-6 lg:px-8">
                    
                    <form onSubmit={submit} className="space-y-6">
                        
                        {/* --- KONTAINER 1: IDENTITAS UTAMA --- */}
                        <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border-l-4 border-teal-500">
                            <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
                                <div className="p-2 bg-teal-50 dark:bg-teal-900/30 rounded-lg">
                                    <PencilLine className="w-6 h-6 text-teal-600 dark:text-teal-400" />
                                </div>
                                <div>
                                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Edit Identitas Unit</h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Perbarui informasi dasar unit kerja.</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="relative pb-2">
                                    <InputLabel value="Kode Unit" required />
                                    <TextInput
                                        value={data.kode_unit}
                                        onChange={(e) => handleFieldChange('kode_unit', e.target.value)}
                                        className={`mt-1 block w-full bg-gray-50 ${(formErrors.kode_unit || errors.kode_unit) ? 'border-rose-500 ring-2 ring-rose-500/20 focus:ring-rose-500 focus:border-rose-500' : ''}`}
                                        placeholder="Cth: 1.01"
                                    />
                                    <FieldTooltipError message={formErrors.kode_unit || errors.kode_unit} />
                                </div>

                                <div className="relative pb-2">
                                    <InputLabel value="Nama Unit Kerja" required />
                                    <TextInput
                                        value={data.nama_unit}
                                        onChange={(e) => handleFieldChange('nama_unit', e.target.value)}
                                        className={`mt-1 block w-full ${(formErrors.nama_unit || errors.nama_unit) ? 'border-rose-500 ring-2 ring-rose-500/20 focus:ring-rose-500 focus:border-rose-500' : ''}`}
                                        placeholder="Cth: Biro Administrasi Umum"
                                    />
                                    <FieldTooltipError message={formErrors.nama_unit || errors.nama_unit} />
                                </div>

                                <div className="relative pb-2">
                                    <InputLabel value="Tipe Unit" required />
                                    <CustomSelect
                                        value={data.tipe_unit}
                                        onChange={(e) => handleFieldChange('tipe_unit', e.target.value)}
                                        options={tipeOptions}
                                        placeholder="Pilih Tipe"
                                        className={`mt-1 ${(formErrors.tipe_unit || errors.tipe_unit) ? 'border-rose-500 ring-2 ring-rose-500/20 focus:ring-rose-500 focus:border-rose-500' : ''}`}
                                    />
                                    <FieldTooltipError message={formErrors.tipe_unit || errors.tipe_unit} />
                                </div>

                                {/* Parent Unit */}
                                <div className="relative pb-2">
                                    <InputLabel value="Unit Induk (Parent)" />
                                    <CustomSelect
                                        value={data.parent_id}
                                        onChange={(e) => handleFieldChange('parent_id', e.target.value)}
                                        options={parentOptions}
                                        placeholder="Pilih Unit Induk (Opsional)"
                                        className="mt-1"
                                    />
                                    <FieldTooltipError message={formErrors.parent_id || errors.parent_id} />
                                </div>
                            </div>
                        </div>

                        {/* --- KONTAINER 2: STRUKTUR & KONTAK --- */}
                        <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border-l-4 border-indigo-500">
                            <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
                                <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg">
                                    <UserCircle className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                                </div>
                                <div>
                                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Struktur & Kontak</h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Pimpinan unit dan informasi kontak.</p>
                                </div>
                            </div>

                            <div className="space-y-6">
                                {/* Kepala Unit */}
                                <div className="relative pb-2">
                                    <InputLabel value="Kepala Unit" />
                                    <CustomSelect
                                        value={data.id_kepala}
                                        onChange={(e) => handleFieldChange('id_kepala', e.target.value)}
                                        options={userOptions}
                                        placeholder="Pilih Pejabat / Kepala Unit"
                                        className="mt-1"
                                    />
                                    <FieldTooltipError message={formErrors.id_kepala || errors.id_kepala} />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="relative pb-2">
                                        <InputLabel value="No. Telepon / WhatsApp" />
                                        <div className="relative mt-1">
                                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                                <Phone className="w-4 h-4 text-gray-400" />
                                            </div>
                                            <TextInput
                                                value={data.no_telepon}
                                                onChange={(e) => handleFieldChange('no_telepon', e.target.value)}
                                                className="pl-10 block w-full"
                                                placeholder="Masukkan Nomor Telepon / WhatsApp"
                                            />
                                        </div>
                                        <FieldTooltipError message={formErrors.no_telepon || errors.no_telepon} />
                                    </div>

                                    <div className="relative pb-2">
                                        <InputLabel value="Email Resmi" />
                                        <div className="relative mt-1">
                                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                                <Mail className="w-4 h-4 text-gray-400" />
                                            </div>
                                            <TextInput
                                                type="email"
                                                value={data.email}
                                                onChange={(e) => handleFieldChange('email', e.target.value)}
                                                className="pl-10 block w-full"
                                                placeholder="Masukkan Email Resmi Unit"
                                            />
                                        </div>
                                        <FieldTooltipError message={formErrors.email || errors.email} />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* --- KONTAINER 3: KONFIGURASI SISTEM --- */}
                        <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border-l-4 border-gray-500">
                            <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
                                <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                                    <Settings2 className="w-6 h-6 text-gray-600 dark:text-gray-300" />
                                </div>
                                <div>
                                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Konfigurasi Sistem</h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Pengaturan tipe dan alur approval.</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2 relative pb-2">
                                    <InputLabel htmlFor="approval_path_id">
                                        Alur Persetujuan <span className="text-red-500">*</span>
                                    </InputLabel>
                                    <CustomSelect
                                        value={data.approval_path_id}
                                        onChange={(e) => handleFieldChange('approval_path_id', e.target.value)}
                                        options={approvalPaths ? approvalPaths.map((path) => ({ value: path.id, label: path.name })) : []}
                                        placeholder="Pilih Alur Persetujuan"
                                        className={`mt-1 ${(formErrors.approval_path_id || errors.approval_path_id) ? 'border-rose-500 ring-2 ring-rose-500/20 focus:ring-rose-500 focus:border-rose-500' : ''}`}
                                    />
                                    <FieldTooltipError message={formErrors.approval_path_id || errors.approval_path_id} />
                                </div>


                            </div>
                        </div>

                        {/* --- TOMBOL AKSI --- */}
                        <div className="sticky bottom-4 z-30 bg-white/90 dark:bg-gray-800/90 backdrop-blur-md p-4 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 flex justify-between items-center">
                            <button
                                type="button"
                                onClick={handleBack}
                                className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white font-medium text-sm flex items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                            >
                                <ArrowLeft size={16} className="mr-2" /> Batal
                            </button>
                            
                            <PrimaryButton disabled={processing} className="shadow-teal-200 hover:shadow-teal-400">
                                <Save size={16} className="mr-2" /> Simpan Perubahan
                            </PrimaryButton>
                        </div>

                    </form>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}