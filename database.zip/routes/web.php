<?php

use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\ApprovalController;
use App\Http\Controllers\ApprovalPathController;
use App\Http\Controllers\PencairanDanaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IkuController;
use App\Http\Controllers\KaryawanController;
use App\Http\Controllers\LpjController;
use App\Http\Controllers\MonitoringController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RincianAnggaranController;
use App\Http\Controllers\RkatController;
use App\Http\Controllers\RkatRabItemController;
use App\Http\Controllers\TahunAnggaranController;
use App\Http\Controllers\UnitController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Auth/Login');
});



Route::middleware(['auth', 'verified'])->group(function () {
    // dashboard route
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // === ROUTE DAFTAR AJUAN (RKA Headers) ===
    Route::get('/daftar-ajuan/input', [RkatController::class, 'create'])->name('daftar-ajuan.create');
    Route::post('/daftar-ajuan', [RkatController::class, 'store'])->name('daftar-ajuan.store');
    Route::get('/daftar-ajuan', [RkatController::class, 'index'])->name('daftar-ajuan.index');
    Route::get('/daftar-ajuan/{rkatHeader}', [RkatController::class, 'show'])->name('daftar-ajuan.show');
    Route::get('/daftar-ajuan/{rkatHeader}/edit', [RkatController::class, 'edit'])->name('daftar-ajuan.edit');
    Route::patch('/daftar-ajuan/{rkatHeader}', [RkatController::class, 'update'])->name('daftar-ajuan.update');
    Route::post('/daftar-ajuan/{rkatHeader}/submit', [RkatController::class, 'submit'])->name('daftar-ajuan.submit');
    Route::get('/daftar-ajuan/{rkatHeader}/export', [RkatController::class, 'exportPdf'])->name('daftar-ajuan.export');
    Route::post('/daftar-ajuan/{rkatHeader}/komentar', [RkatController::class, 'storeKomentar'])->name('daftar-ajuan.komentar.store');

    // Karyawan / SDM routes
    Route::get('/karyawan', [KaryawanController::class, 'index'])->name('karyawan.index');
    Route::post('/karyawan', [KaryawanController::class, 'store'])->name('karyawan.store');
    Route::patch('/karyawan/{karyawan}', [KaryawanController::class, 'update'])->name('karyawan.update');
    Route::delete('/karyawan/{karyawan}', [KaryawanController::class, 'destroy'])->name('karyawan.destroy');

    // Unit resource routes (Public view)
    Route::get('/unit', [UnitController::class, 'index'])->name('unit.index');

    // Master IKU
    Route::get('/iku', [IkuController::class, 'index'])->name('iku.index');

    // Standar Biaya Operasional (Public view)
    Route::get('/sbo', [RincianAnggaranController::class, 'index'])->name('sbo.index');

    // Routes for RKAT (RAB items)
    Route::get('/rkat', [RkatRabItemController::class, 'index'])->name('rkat.index');
    Route::get('/rkat/create', [RkatRabItemController::class, 'create'])->name('rkat.create');
    Route::post('/rkat', [RkatRabItemController::class, 'store'])->name('rkat.store');

    // === ROUTE APPROVAL ===
    Route::middleware(['approver'])->group(function () {
        Route::get('/approval', [ApprovalController::class, 'index'])->name('approval.index');
        Route::post('/approval/approve/{rkatHeader}', [ApprovalController::class, 'approve'])->name('approval.process');
    });

    // monitoring route
    Route::get('/monitoring', [MonitoringController::class, 'index'])->name('monitoring.index');
    Route::get('/monitoring/iku-ikk', [MonitoringController::class, 'ikuIkk'])->name('monitoring.iku_ikk');

    // Pencairan Dana
    Route::get('/pencairan', [PencairanDanaController::class, 'index'])->name('pencairan.index');
    Route::post('/pencairan', [PencairanDanaController::class, 'store'])->name('pencairan.store');
    Route::get('/pencairan/approval', [PencairanDanaController::class, 'approvalIndex'])->name('pencairan.approval');
    Route::get('/pencairan/{pencairan}', [PencairanDanaController::class, 'show'])->name('pencairan.show');
    Route::put('/pencairan/{pencairan}', [PencairanDanaController::class, 'update'])->name('pencairan.update');
    Route::post('/pencairan/{pencairan}/submit', [PencairanDanaController::class, 'submit'])->name('pencairan.submit');
    Route::post('/pencairan/{pencairan}/approve', [PencairanDanaController::class, 'approve'])->name('pencairan.approve');
    Route::get('/pencairan/{pencairan}/export', [PencairanDanaController::class, 'exportPdf'])->name('pencairan.export');

    // LPJ
    Route::get('/lpj', [LpjController::class, 'index'])->name('lpj.index');
    Route::post('/lpj', [LpjController::class, 'store'])->name('lpj.store');
    Route::get('/lpj/{lpj}', [LpjController::class, 'show'])->name('lpj.show');
    Route::put('/lpj/{lpj}', [LpjController::class, 'update'])->name('lpj.update');
    Route::post('/lpj/{lpj}/submit', [LpjController::class, 'submit'])->name('lpj.submit');
    Route::post('/lpj/{lpj}/approve', [LpjController::class, 'approve'])->name('lpj.approve');
    Route::get('/lpj/{lpj}/export', [LpjController::class, 'exportPdf'])->name('lpj.export');

    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Admin-only routes: Tahun Anggaran and account creation
    Route::middleware(['admin'])->group(function () {
        // Tahun Anggaran management (index, create, store, edit, update, destroy)
        Route::get('/tahun', [TahunAnggaranController::class, 'index'])->name('tahun.index');
        Route::get('/tahun/create', fn() => redirect()->route('tahun.index'));
        Route::post('/tahun', [TahunAnggaranController::class, 'store'])->name('tahun.store');
        Route::get('/tahun/{tahun}/edit', fn() => redirect()->route('tahun.index'));
        Route::patch('/tahun/{tahun}', [TahunAnggaranController::class, 'update'])->name('tahun.update');
        Route::delete('/tahun/{tahun}', [TahunAnggaranController::class, 'destroy'])->name('tahun.destroy');

        // Rincian Anggaran (master akun anggaran)
        Route::get('/sbo/create', fn() => redirect()->route('sbo.index'));
        Route::post('/sbo', [RincianAnggaranController::class, 'store'])->name('sbo.store');
        Route::get('/sbo/{rincian}/edit', fn() => redirect()->route('sbo.index'));
        Route::patch('/sbo/{rincian}', [RincianAnggaranController::class, 'update'])->name('sbo.update');
        Route::delete('/sbo/{rincian}', [RincianAnggaranController::class, 'destroy'])->name('sbo.destroy');

        // Admin-only user management
        Route::get('/user', [UserController::class, 'index'])->name('user.index');
        Route::get('/user/create', [UserController::class, 'create'])->name('user.create');
        Route::post('/user', [UserController::class, 'store'])->name('user.store');
        Route::get('/user/{user}/edit', [UserController::class, 'edit'])->name('user.edit');
        Route::patch('/user/{user}', [UserController::class, 'update'])->name('user.update');
        Route::delete('/user/{user}', [UserController::class, 'destroy'])->name('user.destroy');
        Route::patch('/user/{user}/password', [UserController::class, 'updatePassword'])->name('user.password.update');

        // Unit management
        Route::get('/unit/create', [UnitController::class, 'create'])->name('unit.create');
        Route::post('/unit', [UnitController::class, 'store'])->name('unit.store');
        Route::get('/unit/{unit}/edit', [UnitController::class, 'edit'])->name('unit.edit');
        Route::patch('/unit/{unit}', [UnitController::class, 'update'])->name('unit.update');
        Route::delete('/unit/{unit}', [UnitController::class, 'destroy'])->name('unit.destroy');

        // Master IKU & IKK Management
        Route::post('/iku/master', [IkuController::class, 'storeMaster'])->name('iku.master.store');
        Route::post('/iku/annual', [IkuController::class, 'storeAnnual'])->name('iku.annual.store');
        Route::put('/iku/{iku}', [IkuController::class, 'updateUnified'])->name('iku.update');
        Route::post('/iku/copy-year', [IkuController::class, 'copyFromPreviousYear'])->name('iku.copy_year');
        Route::delete('/iku/{iku}', [IkuController::class, 'destroy'])->name('iku.destroy');

        // IKK Management
        Route::get('/iku/input-ikk', [IkuController::class, 'create'])->name('iku.create');
        Route::post('/iku/sync-ikk', [IkuController::class, 'store'])->name('iku.store');
        // Approval Paths Settings
        Route::get('approval-path', [ApprovalPathController::class, 'index'])->name('approval-path.index');
        Route::get('approval-path/create', fn() => redirect()->route('approval-path.index'));
        Route::post('approval-path', [ApprovalPathController::class, 'store'])->name('approval-path.store');
        Route::get('approval-path/{approvalPath}/edit', fn() => redirect()->route('approval-path.index'));
        Route::patch('approval-path/{approvalPath}', [ApprovalPathController::class, 'update'])->name('approval-path.update');
        Route::delete('approval-path/{approvalPath}', [ApprovalPathController::class, 'destroy'])->name('approval-path.destroy');

    });
});

require __DIR__ . '/auth.php';
